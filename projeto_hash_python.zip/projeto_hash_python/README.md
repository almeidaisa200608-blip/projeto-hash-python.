# Projeto: Codificador e Hash de Senhas

Este projeto foi feito para praticar conceitos básicos de Python, como strings, funções, laços `for`, `ord()` e `return`.

## O que ele faz?

- Codifica letras usando um dicionário de substituição.
- Mantém números e símbolos sem alteração.
- Calcula um hash didático somando o valor Unicode de cada caractere.

## Como executar

1. Instale o Python 3, se ainda não tiver.
2. Abra o terminal na pasta do projeto.
3. Execute:

```bash
python main.py
```

## Importante

A codificação por substituição e a soma de `ord()` são apenas exercícios didáticos. Elas não protegem senhas reais e não devem ser usadas para armazenar senhas. Para aplicações reais, use algoritmos próprios para senhas, como Argon2 ou bcrypt.
